package Ferrari;

public class Main {
}
