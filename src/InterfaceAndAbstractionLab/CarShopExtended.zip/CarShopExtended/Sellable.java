package CarShopExtended;

public interface Sellable {
    public Double getPrice();
}
