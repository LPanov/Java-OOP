package SayHello;

public interface Person {
    public String getName();
    public String sayHello();
}
