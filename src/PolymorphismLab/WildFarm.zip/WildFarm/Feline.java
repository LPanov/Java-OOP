package WildFarm;

public abstract class Feline extends Mammal{
    public Feline(String animalName, String animalType, double animalWeight, int foodEaten, String livingRegion) {
        super(animalName, animalType, animalWeight, foodEaten, livingRegion);
    }
}
