package barracksWars.core.factories;

import barracksWars.interfaces.Unit;
import barracksWars.interfaces.UnitFactory;
import jdk.jshell.spi.ExecutionControl;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class UnitFactoryImpl implements UnitFactory {

	private static final String UNITS_PACKAGE_NAME =
			"barracksWars.models.units.";

	@Override
	public Unit createUnit(String unitType) throws ExecutionControl.NotImplementedException {
		String className = "barracksWars.models.units." + unitType;
		Object unit;
		try {
			Class clazz = Class.forName(className);
			Constructor constructor = clazz.getDeclaredConstructor();

			unit = constructor.newInstance();

		} catch (ClassNotFoundException e) {
			throw new RuntimeException("message");
		} catch (NoSuchMethodException e) {
            throw new RuntimeException("message");
        } catch (InvocationTargetException e) {
            throw new RuntimeException("message");
        } catch (InstantiationException e) {
            throw new RuntimeException("message");
        } catch (IllegalAccessException e) {
            throw new RuntimeException("message");
        }

		return (Unit) unit;
    }
}
