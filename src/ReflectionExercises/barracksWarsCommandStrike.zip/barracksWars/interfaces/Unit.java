package barracksWars.interfaces;

public interface Unit extends Destroyable, Attacker {
}
