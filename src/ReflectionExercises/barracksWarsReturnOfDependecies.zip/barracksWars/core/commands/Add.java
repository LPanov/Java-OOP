package barracksWars.core.commands;

import barracksWars.annotations.Inject;
import barracksWars.interfaces.Executable;
import barracksWars.interfaces.Repository;
import barracksWars.interfaces.Unit;
import barracksWars.interfaces.UnitFactory;
import jdk.jshell.spi.ExecutionControl;

public class Add implements Executable {
    @Inject
    private Repository repository;
    @Inject
    private UnitFactory unitFactory;
    @Inject
    private String[] data;
    public Add(){}
    public Add(String[] data, Repository repository, UnitFactory unitFactory) {

        this.data = data;
        this.repository = repository;
        this.unitFactory = unitFactory;
    }

    @Override
    public String execute() {
        String unitType = this.data[1];
        Unit unitToAdd;
        try {
           unitToAdd = this.unitFactory.createUnit(unitType);
        } catch (ExecutionControl.NotImplementedException e) {
            throw new RuntimeException(e);
        }
        this.repository.addUnit(unitToAdd);

        return unitType + " added!";
    }
}
