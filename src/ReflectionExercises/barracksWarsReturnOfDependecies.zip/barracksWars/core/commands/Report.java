package barracksWars.core.commands;

import barracksWars.annotations.Inject;
import barracksWars.interfaces.Executable;
import barracksWars.interfaces.Repository;
import barracksWars.interfaces.UnitFactory;

public class Report implements Executable {
    @Inject
    private Repository repository;

    public Report() {}
    public Report(Repository repository) {
        this.repository = repository;
    }

    @Override
    public String execute() {
        String output = this.repository.getStatistics();
        return output;
    }
}
