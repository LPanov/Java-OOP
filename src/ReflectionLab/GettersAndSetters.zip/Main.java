import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.TreeMap;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        Class reflection = Reflection.class;

        Object reflectionObject = reflection.getDeclaredConstructor().newInstance();

        Method[] methods = reflectionObject.getClass().getDeclaredMethods();
        Map<String, String> getters = new TreeMap<>();
        Map<String, String> setters = new TreeMap<>();

        for (int i = 0; i < methods.length; i++) {
            String name = methods[i].getName();
            if (name.startsWith("set")) {
                String str = name + " and will set field of class " + methods[i].getParameterTypes()[0].getName().replace("class", "");
                setters.putIfAbsent(name, str);
            }
            else if (name.startsWith("get")){
                String str = name + " will return class " + methods[i].getReturnType().getName().replace("class", "");
                getters.putIfAbsent(name, str);
            }
        }

        getters.values().forEach(System.out::println);
        setters.values().forEach(System.out::println);
    }
}
