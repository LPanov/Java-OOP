//package EncapsulationExercises.PizzaCalories;
package PizzaCalories;
public enum BakingTechnique {
    Crispy,
    Chewy,
    Homemade,

}
