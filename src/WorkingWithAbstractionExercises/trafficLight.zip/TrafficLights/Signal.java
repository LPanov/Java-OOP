package WorkingWithAbstractionExercises.TrafficLights;

public enum Signal {
    RED,
    YELLOW,
    GREEN,
}
