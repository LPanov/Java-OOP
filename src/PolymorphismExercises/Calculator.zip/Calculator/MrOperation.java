package Calculator;

import java.util.ArrayList;
import java.util.List;

public class MrOperation {
    private MsOperation msOperation;

    public MrOperation(MsOperation operation){
        this.msOperation = operation;
    }

    public MsOperation getMsOperation() {
        return msOperation;
    }

    public int getResult() {
        return this.getMsOperation().getResult();
    }
}

