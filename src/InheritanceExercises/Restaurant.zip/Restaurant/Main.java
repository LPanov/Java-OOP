package Restaurant;

public class Main {
}
