package Restaurant;

import java.math.BigDecimal;

public class Soup extends Starter{
    public Soup(String name, BigDecimal price, double grams, double calories) {
        super(name, price, grams, calories);
    }
}
