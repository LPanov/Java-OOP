package Telephony;

public interface Browsable {
    public String browse();
}
