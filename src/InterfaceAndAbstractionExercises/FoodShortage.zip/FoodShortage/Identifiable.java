package FoodShortage;

public interface Identifiable {
    public String getId();
}
