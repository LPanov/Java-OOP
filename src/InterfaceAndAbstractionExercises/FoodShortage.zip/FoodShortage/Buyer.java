package FoodShortage;

public interface Buyer {
    public void buyFood();
    public int getFood();
}
