package BirthdayCelebrations;

public class Main {
}
