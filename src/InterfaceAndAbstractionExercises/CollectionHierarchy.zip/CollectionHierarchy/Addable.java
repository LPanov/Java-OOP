package CollectionHierarchy;

public interface Addable {
    public int add(String str);
}
