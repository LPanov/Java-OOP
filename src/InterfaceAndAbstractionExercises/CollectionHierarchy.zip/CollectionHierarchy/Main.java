package CollectionHierarchy;

public class Main {
}
