package CollectionHierarchy;

public interface AddRemovable extends Addable{
    public String remove();
}
