package MilitaryElite;

public interface Soldier {
    public int getId();
    public String getFirstName();
    public String getLastName();
}
