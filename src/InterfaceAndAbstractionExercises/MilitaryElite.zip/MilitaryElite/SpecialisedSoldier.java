package MilitaryElite;

public interface SpecialisedSoldier {
    public Corps getCorps();
}
