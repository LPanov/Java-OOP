package MilitaryElite;

public interface Private {
    public double getSalary();
}
