package MilitaryElite;

public interface LieutenantGeneral {
    public void addPrivate(PrivateImpl priv);
}
