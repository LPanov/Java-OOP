package MilitaryElite;

public interface Spy {
    public String getCodeNumber();
}
