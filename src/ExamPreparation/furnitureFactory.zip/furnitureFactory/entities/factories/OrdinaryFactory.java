package furnitureFactory.entities.factories;

import furnitureFactory.entities.workshops.Workshop;

import static furnitureFactory.common.ExceptionMessages.NON_SUPPORTED_WORKSHOP;

public class OrdinaryFactory extends BaseFactory{
    public OrdinaryFactory(String name) {
        super(name);
    }

}
