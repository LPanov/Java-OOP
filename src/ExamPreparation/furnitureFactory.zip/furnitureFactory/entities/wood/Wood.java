package furnitureFactory.entities.wood;

public interface Wood {

    int getWoodQuantity();
}
